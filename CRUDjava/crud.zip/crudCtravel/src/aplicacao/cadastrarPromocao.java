package aplicacao;

import DAO.promocaoDAO;
import crudCtravel.model.promocao;

public class cadastrarPromocao {

	public static void main(String[] args) {
		
	// Cadastrar Promocao
		
		promocao promocao = new promocao();
		
		promocao promocao1 = new promocao();
		promocao.setNome("Hello oi");
		promocao.setDesconto(50);
		promocao.setDestino(5);
		
		promocaoDAO.save(promocao);
				

	}

}