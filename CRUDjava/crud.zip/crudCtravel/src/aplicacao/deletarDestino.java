package aplicacao;

import DAO.destinoDAO;

public class deletarDestino {

	public static void main(String[] args) {
		
		// Deletar algúm destino pelo número de ID
		
		destinoDAO.deleteById(6);
		

	}

}
