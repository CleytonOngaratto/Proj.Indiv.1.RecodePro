package aplicacao;

import DAO.destinoDAO;
import crudCtravel.model.destino;

public class listarDestinos {

	public static void main(String[] args) {
		
		// visualização dos destinos do banco de dados
		
		for(destino d : destinoDAO.getDestinos()) {
			System.out.println("destino: "+d.getCidade());
		}
	}

}
