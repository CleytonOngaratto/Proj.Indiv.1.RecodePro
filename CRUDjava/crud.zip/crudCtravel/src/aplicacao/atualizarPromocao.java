package aplicacao;

import DAO.promocaoDAO;
import crudCtravel.model.promocao;

public class atualizarPromocao {

	public static void main(String[] args) {
		// Atualizar promoção
		
		
		promocao p1 = new promocao();
		p1.setNome("Teste ");
		p1.setDesconto(700);
		p1.setDestino(1); 
		p1.setId(0);

		
		promocaoDAO.update(p1);

	}

}
