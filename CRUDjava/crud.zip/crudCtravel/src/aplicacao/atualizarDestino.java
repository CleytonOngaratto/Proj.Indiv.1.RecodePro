package aplicacao;

import DAO.destinoDAO;
import crudCtravel.model.destino;

public class atualizarDestino {

	public static void main(String[] args) {
		
		// Atualizar destino
		
		destino d1 = new destino();
		d1.setCidade("Belo Horizonte");
		d1.setValor(700);
		d1.setId(5);
		
		destinoDAO.update(d1);

	}

}
