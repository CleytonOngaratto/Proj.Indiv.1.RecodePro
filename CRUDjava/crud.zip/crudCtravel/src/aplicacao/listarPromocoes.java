package aplicacao;

import DAO.promocaoDAO;
import crudCtravel.model.promocao;

public class listarPromocoes {

	public static void main(String[] args) {
		
		// visualização das promoções cadastradas
		
		for(promocao p : promocaoDAO.getPromocoes()) {
			System.out.println("promocao: "+p.getNome());
		}
	}

}

