package aplicacao;


import DAO.destinoDAO;
import crudCtravel.model.destino;

public class cadastrarDestino {

	public static void main(String[] args) {
		
		// Cadastrar Destino
		
		destinoDAO destinoDAO = new destinoDAO();
		
		destino destino = new destino();
		destino.setCidade(" ");
		destino.setValor(0);
		
		destinoDAO.save(destino);
				

	}

}
