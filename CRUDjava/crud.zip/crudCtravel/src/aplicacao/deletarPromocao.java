package aplicacao;

import DAO.promocaoDAO;

public class deletarPromocao {

	public static void main(String[] args) {
		
		// Deletar alguma promoção  pelo número de ID
		
				promocaoDAO.deleteById(10);
				

			}

		}
