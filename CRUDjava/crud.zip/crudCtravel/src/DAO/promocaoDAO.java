package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import crudCtravel.model.destino;
import crudCtravel.model.promocao;
import factory.ConnectionFactory;

public class promocaoDAO {
	
	// CREATE (Cadastrar)
	public static void save(promocao promocao) {
		
		String sql = "INSERT INTO promocao (nome, desconto, destino) VALUES (?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {

			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);

			pstm.setString(1, promocao.getNome());
			pstm.setDouble(2, promocao.getDesconto());
			pstm.setInt(3, promocao.getDestino());

			pstm.execute();
			
			System.out.println("Promoção salva com sucesso");
			
		} catch (Exception erro) {
			erro.printStackTrace();
		} finally {

			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	
	
	
	//READ (Listar)
	public static List<promocao> getPromocoes(){
		
		String sql = "SELECT * FROM promocao";
		
		List<promocao> promocoes = new ArrayList<promocao>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		//Classe que vai recuperar os dados do banco  ******SELECT******
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				promocao promocao = new promocao();
				
				
				//Recuperar a promoção
				promocao.setNome(rset.getString("nome"));
				//Recuperar o valor
				promocao.setDesconto(rset.getFloat("desconto"));
				promocao.setDestino(rset.getInt("destino"));
				
				promocoes.add(promocao);
			}	
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rset!=null) {
					rset.close();
				}
				if(pstm!=null) {
					pstm.close();
				}
				if(conn!=null) {
					conn.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return promocoes;
				
	}


		

	//UPDATE (Atualizar)
	public static void update(promocao p1) {
		String sql = "UPDATE promocao SET nome = ?, desconto = ?, destino = ? WHERE id_promocao =?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			// Criar uma conexão com o banco de dados
			conn = ConnectionFactory.createConnectionToMySQL();
			
			//Criei uma PreparedStatement, para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			//Adicionar os valores para atualizar
			pstm.setString(1, p1.getNome());
			pstm.setDouble(2, p1.getDesconto());
			pstm.setInt(3, p1.getDestino());
			pstm.setInt(4, p1.getId());
			
			//Executar a query
			pstm.execute();
			
			System.out.println("Promoção atualizada com sucesso");
			
		} catch (Exception erro) {
			erro.printStackTrace();
		} finally {
			
			//Fechar as conexões
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
	}	
	



	//DELETE
	public static void deleteById(int id) {
		String sql = "DELETE FROM promocao WHERE id_promocao = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
			System.out.println("Promoção deletada com sucesso");
			
		} catch (Exception erro) {
			erro.printStackTrace();
		} finally {	
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
	}
	
	
	
	
	}
	
	
	
	

