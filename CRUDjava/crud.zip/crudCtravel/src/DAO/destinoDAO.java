package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import crudCtravel.model.destino;
import factory.ConnectionFactory;

public class destinoDAO {
	
	// CREATE (Cadastrar)
	public void save(destino destino) {
		
		String sql = "INSERT INTO destino (cidade, valor) VALUES (?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			// Criar uma conexão com o banco de dados
			conn = ConnectionFactory.createConnectionToMySQL();
			
			
			//Criei uma PreparedStatement, para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			//Adicionar os valores que são esperados pela query
			pstm.setString(1, destino.getCidade());
			pstm.setDouble(2, destino.getValor());
			
			//Executar a query
			pstm.execute();
			
			System.out.println("Destino salvo com sucesso");
			
		} catch (Exception erro) {
			erro.printStackTrace();
		} finally {
			
			//Fechar as conexões
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	
	
	
	//READ (Listar)
	public static List<destino> getDestinos(){
		
		String sql = "SELECT * FROM destino";
		
		List<destino> destinos = new ArrayList<destino>();
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		//Classe que vai recuperar os dados do banco  ******SELECT******
		ResultSet rset = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				destino destino = new destino();
				
				//Recuperar o ID
				// destino.setId(rset.getInt("id"));
				
				//Recuperar a cidade
				destino.setCidade(rset.getString("cidade"));
				//Recuperar o valor
				destino.setValor(rset.getFloat("valor"));
				
				destinos.add(destino);
			}	
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rset!=null) {
					rset.close();
				}
				if(pstm!=null) {
					pstm.close();
				}
				if(conn!=null) {
					conn.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return destinos;
				
	}


		

	//UPDATE (Atualizar)
	public static void update(destino destino) {
		String sql = "UPDATE destino SET cidade = ?, valor = ? "+"WHERE id_destino =?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			// Criar uma conexão com o banco de dados
			conn = ConnectionFactory.createConnectionToMySQL();
			
			//Criei uma PreparedStatement, para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			//Adicionar os valores para atualizar
			pstm.setString(1, destino.getCidade());
			pstm.setDouble(2, destino.getValor());
			pstm.setInt(3, destino.getId());
			
			//Executar a query
			pstm.execute();
			
			System.out.println("Destino atualizado com sucesso");
			
		} catch (Exception erro) {
			erro.printStackTrace();
		} finally {
			
			//Fechar as conexões
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
	}	
	



	//DELETE
	public static void deleteById(int id) {
		String sql = "DELETE FROM destino WHERE id_destino = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
			System.out.println("Destino deletado com sucesso");
			
		} catch (Exception erro) {
			erro.printStackTrace();
		} finally {	
			try {
				if(pstm!=null) {
					pstm.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}catch (Exception erro) {
				erro.printStackTrace();
			}
		}
		
	}
	
	
	
	
	}
	
	
	
	
	


